package FlashTicket;

public class Utente {
    public String nome;
    public String password;
    public String ruolo; 
    public String dipartimento;

    public Utente(String nome, String password, String ruolo, String dipartimento) {
        this.nome = nome;
        this.password = password;
        this.ruolo = ruolo;
        this.dipartimento = dipartimento;
    }
}