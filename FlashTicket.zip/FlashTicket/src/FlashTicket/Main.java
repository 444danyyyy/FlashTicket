package FlashTicket;

public class Main {
    public static void main(String[] args) {
        new FlashTicketGUI();
    }
}