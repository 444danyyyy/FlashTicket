package FlashTicket;
	
public class Ticket {
    public int id;
    public String dipendente;
    public String dipartimento;
    public String descrizione;
    public String priorita;
    public boolean completato;

    public Ticket(int id, String dipendente, String dipartimento, String descrizione, String priorita) {
        this.id = id;
        this.dipendente = dipendente;
        this.dipartimento = dipartimento;
        this.descrizione = descrizione;
        this.priorita = priorita;
        this.completato = false;
    }

    @Override
    public String toString() {
        String stato = completato ? "[CHIUSO]" : "[APERTO]";
        return stato + " #" + id + " [" + priorita + "] - " + dipartimento + " → " + descrizione;
    }
}