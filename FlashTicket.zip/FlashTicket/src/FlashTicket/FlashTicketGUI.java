package FlashTicket;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class FlashTicketGUI extends JFrame {
    private ArrayList<Utente> utenti;
    private ArrayList<Ticket> tickets;
    private int contatoreTicket = 1;
    private Utente utenteLoggato;
    private JPanel mainPanel;
    private CardLayout layout;
    
    public FlashTicketGUI() {
        super("Flash Ticket - Gestione Globale");
        utenti = GestoreDati.caricaUtenti();
        tickets = GestoreDati.caricaTickets();
        
        // Calcolo ID per non sovrascrivere
        if (!tickets.isEmpty()) {
            contatoreTicket = tickets.get(tickets.size() - 1).id + 1;
        }

        layout = new CardLayout();
        mainPanel = new JPanel(layout);
        initLogin();
        
        add(mainPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(550, 450);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initLogin() {
        JPanel loginPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        loginPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        JTextField txtUser = new JTextField();
        JPasswordField txtPass = new JPasswordField();
        JButton btnLogin = new JButton("Accedi");

        loginPanel.add(new JLabel("Username:"));
        loginPanel.add(txtUser);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(txtPass);
        loginPanel.add(new JLabel("")); 
        loginPanel.add(btnLogin);

        btnLogin.addActionListener(e -> {
            String user = txtUser.getText();
            String pass = new String(txtPass.getPassword());
            for (Utente u : utenti) {
                if (u.nome.equalsIgnoreCase(user) && u.password.equals(pass)) {
                    utenteLoggato = u;
                    if (u.ruolo.equals("DIPENDENTE")) {
                        initAreaDipendente();
                        layout.show(mainPanel, "DIPENDENTE");
                    } else {
                        initAreaTecnico();
                        layout.show(mainPanel, "TECNICO");
                    }
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "Credenziali errate!");
        });
        mainPanel.add(loginPanel, "LOGIN");
    }

    private void initAreaDipendente() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JLabel info = new JLabel("Bentornato " + utenteLoggato.nome + " (" + utenteLoggato.dipartimento + ")");
        
        JPanel form = new JPanel(new GridLayout(5, 1));
        String[] opzioni = {"Stampante non funzionante", "Internet assente", "Errore Software", "Altro..."};
        JComboBox<String> comboProblemi = new JComboBox<>(opzioni);
        JTextField txtAltro = new JTextField();
        txtAltro.setEnabled(false);
        comboProblemi.addActionListener(e -> txtAltro.setEnabled(comboProblemi.getSelectedItem().equals("Altro...")));

        String[] priorita = {"Bassa", "Media", "Alta"};
        JComboBox<String> comboPrio = new JComboBox<>(priorita);
        JButton btnInvia = new JButton("Invia Segnalazione");

        form.add(new JLabel("Seleziona Problema:"));
        form.add(comboProblemi);
        form.add(txtAltro);
        form.add(new JLabel("Priorità:"));
        form.add(comboPrio);

        btnInvia.addActionListener(e -> {
            String d = comboProblemi.getSelectedItem().toString();
            if (d.equals("Altro...")) d = txtAltro.getText();
            Ticket t = new Ticket(contatoreTicket++, utenteLoggato.nome, utenteLoggato.dipartimento, d, comboPrio.getSelectedItem().toString());
            tickets.add(t);
            GestoreDati.salvaTickets(tickets);
            JOptionPane.showMessageDialog(this, "Ticket aperto correttamente!");
        });

        p.add(info, BorderLayout.NORTH);
        p.add(form, BorderLayout.CENTER);
        p.add(btnInvia, BorderLayout.SOUTH);
        mainPanel.add(p, "DIPENDENTE");
    }

    private void initAreaTecnico() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        DefaultListModel<Ticket> model = new DefaultListModel<>();
        JList<Ticket> listaTicket = new JList<>(model);
        
        JButton btnAggiorna = new JButton("Visualizza/Ordina Ticket Aziendali");
        JButton btnCompleta = new JButton("Segna come Risolto");

        btnAggiorna.addActionListener(e -> {
            model.clear();
            // Il tecnico vede TUTTI i ticket ordinati per priorità
            String[] ordine = {"Alta", "Media", "Bassa"};
            for (String pr : ordine) {
                for (Ticket t : tickets) {
                    if (t.priorita.equals(pr) && !t.completato) model.addElement(t);
                }
            }
        });

        btnCompleta.addActionListener(e -> {
            Ticket sel = listaTicket.getSelectedValue();
            if (sel != null) {
                sel.completato = true;
                model.removeElement(sel);
                GestoreDati.salvaTickets(tickets);
                JOptionPane.showMessageDialog(this, "Ticket risolto!");
            }
        });

        p.add(new JLabel("PANNELLO TECNICO GLOBALE (Accesso a tutti i reparti)"), BorderLayout.NORTH);
        p.add(new JScrollPane(listaTicket), BorderLayout.CENTER);
        JPanel bottoni = new JPanel();
        bottoni.add(btnAggiorna);
        bottoni.add(btnCompleta);
        p.add(bottoni, BorderLayout.SOUTH);
        
        btnAggiorna.doClick(); // Caricamento automatico all'apertura
        mainPanel.add(p, "TECNICO");
    }

    public static void main(String[] args) {
        new FlashTicketGUI();
    }
}