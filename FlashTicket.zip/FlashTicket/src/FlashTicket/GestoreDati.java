package FlashTicket;

import java.io.*;
import java.util.ArrayList;

public class GestoreDati {
    
    public static ArrayList<Utente> caricaUtenti() {
        ArrayList<Utente> lista = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader("credenziali.txt"));
            String riga;
            while ((riga = br.readLine()) != null) {
                String[] parti = riga.split(",");
                if (parti.length == 4) {
                    lista.add(new Utente(parti[0], parti[1], parti[2], parti[3]));
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Errore file credenziali");
        }
        return lista;
    }

    public static void salvaTickets(ArrayList<Ticket> tickets) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("tickets.txt"));
            for (Ticket t : tickets) {
                bw.write(t.id + ";;" + t.dipendente + ";;" + t.dipartimento + ";;" + t.descrizione + ";;" + t.priorita + ";;" + t.completato);
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {
            System.out.println("Errore salvataggio");
        }
    }

    public static ArrayList<Ticket> caricaTickets() {
        ArrayList<Ticket> lista = new ArrayList<>();
        try {
            File f = new File("tickets.txt");
            if (!f.exists()) return lista;
            BufferedReader br = new BufferedReader(new FileReader(f));
            String riga;
            while ((riga = br.readLine()) != null) {
                String[] parti = riga.split(";;");
                if (parti.length == 6) {
                    Ticket t = new Ticket(Integer.parseInt(parti[0]), parti[1], parti[2], parti[3], parti[4]);
                    t.completato = Boolean.parseBoolean(parti[5]);
                    lista.add(t);
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Errore caricamento ticket");
        }
        return lista;
    }
}